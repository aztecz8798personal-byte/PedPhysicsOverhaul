This is a failed attempt  by me Aztecz8798 who was trying to make a mod to bring back the great physics of GTA iv in GTA V tried my best but can't keep up with the errors if anybody wants kindly update it post it on your account or do anything just give credits if you post this anywhere just mention my name in Authors too.

Indentatation and Formattion done by GPT-5
Written by Aztecz8798